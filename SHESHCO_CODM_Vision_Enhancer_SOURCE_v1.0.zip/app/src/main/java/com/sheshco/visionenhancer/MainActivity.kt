package com.sheshco.visionenhancer

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var brightness: SeekBar
    private lateinit var brightnessLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF10101A.toInt()
        window.navigationBarColor = 0xFF10101A.toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 34, 28, 28)
            setBackgroundColor(0xFF10101A.toInt())
        }
        fun label(text: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10) }

        root.addView(label("SHESHCO", 27f, 0xFFB68CFF.toInt()))
        root.addView(label("CODM VISION ENHANCER", 16f))
        root.addView(label("Display helper • Non-root • Android 16", 13f, 0xFFB8B8C8.toInt()))
        root.addView(label("SCREEN BRIGHTNESS", 14f, 0xFF55DDE0.toInt()))
        brightnessLabel = label("Brightness: system default", 14f)
        root.addView(brightnessLabel)
        brightness = SeekBar(this).apply { max = 100; progress = 75 }
        root.addView(brightness, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        brightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                brightnessLabel.text = "Brightness: $value%"
                if (fromUser && Settings.System.canWrite(this@MainActivity)) {
                    val v = (value.coerceIn(1, 100) * 255 / 100)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        fun button(text: String, action: () -> Unit) {
            val b = Button(this).apply { this.text = text; isAllCaps = false }
            root.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 10 })
            b.setOnClickListener { action() }
        }
        button("Grant brightness permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        button("Open Display settings (color / contrast)") {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
        button("Open Accessibility settings (color correction)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("Open CODM Garena") {
            val launch = packageManager.getLaunchIntentForPackage("com.garena.game.codm")
            if (launch != null) startActivity(launch)
            else Toast.makeText(this, "CODM Garena not detected", Toast.LENGTH_SHORT).show()
        }
        root.addView(label(
            "IMPORTANT: Android apps cannot directly sharpen or recolor CODM's rendered frames without game-level access. This app adjusts screen brightness (with your permission) and opens Android display settings. Use built-in color correction only if it improves visibility. No ESP, wallhack, game-file edits, or anti-cheat bypass.",
            12f, 0xFFB8B8C8.toInt()
        ))
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
