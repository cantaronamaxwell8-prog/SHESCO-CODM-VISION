# SHESHCO CODM Vision Enhancer

Android Studio project for a non-root display helper, intended for Infinix Smart 20 X6840 / Android 16.

## What it actually does
- Adjusts Android screen brightness after the user grants the special "Modify system settings" permission.
- Opens Android Display settings and Accessibility settings so the user can choose supported system color/contrast options.
- Provides a shortcut to launch CODM Garena (`com.garena.game.codm`).

## Important limitation
A normal third-party Android app cannot directly sharpen CODM's rendered frames or force saturation/contrast only inside the game. Display options vary by firmware. The app does not promise enemy highlighting, through-wall vision, FPS gains, or game modifications.

## Build APK
Push this project to a GitHub repository, then open **Actions → Build SHESHCO Vision Enhancer APK → Run workflow**. Download the `SHESHCO-CODM-Vision-Enhancer-debug` artifact. This workflow builds a debug APK, not a Play Store release-signed APK.
